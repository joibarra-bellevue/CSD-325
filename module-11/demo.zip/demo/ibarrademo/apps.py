from django.apps import AppConfig


class IbarrademoConfig(AppConfig):
    name = 'ibarrademo'
